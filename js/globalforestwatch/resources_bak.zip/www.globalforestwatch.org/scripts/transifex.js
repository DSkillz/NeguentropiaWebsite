window.liveSettings = { api_key: '9eda410a7db74687ba40771c56abd357' };
